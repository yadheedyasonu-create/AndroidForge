VENI Android project (prototype 0.2)

This project contains the MainActivity.java you provided and the Android project
configuration needed to open it in Android Studio.

Build an APK:
1. Install Android Studio on a computer.
2. Open this extracted VENI folder as a project.
3. Allow Gradle sync to finish and install any requested Android SDK platform.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is normally created at app/build/outputs/apk/debug/app-debug.apk.

Note: This environment does not have Android SDK/Gradle installed, so an APK
could not be compiled here. Photo recognition and voice logging are placeholders
in the supplied prototype, as the app's own text indicates.
